# job4j_design
[![Build Status](https://travis-ci.org/ftptpf/job4j_design.svg?branch=master)](https://travis-ci.org/ftptpf/job4j_design)
[![codecov](https://codecov.io/gh/ftptpf/job4j_design/branch/master/graph/badge.svg?token=Q15WI4N5AC)](https://codecov.io/gh/ftptpf/job4j_design)